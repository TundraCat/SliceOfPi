function validate(order){
  
  //console.log(order)
  
  if(order.zip !== 98101){
    alert("Error, we only deliver to 98101");
    return false;
  }
  
  if(order.toppings.length >3){
    alert("Error: cant have more than 3 toppings")
    return false;
  }
  
  return true;
  
}


function buildOrder(){
  var order = {};
  
  order.size = parseInt(document.getElementById('size-input').value);
  
  order.crust = document.getElementById('crust-input').value;
  
  var sauceRadio = document.getElementsByName('sauce');
  for (var i = 0; i < sauceRadio.length;i++) {
    if(sauceRadio[i].checked) {
      order.sauce = sauceRadio[i].value;
    }
  }
  
  order.zip = parseInt(document.getElementById('zip-input').value);
  
  order.toppings = [];
  var toppingsCheckboxes = document.getElementsByName('topping');
  for(i = 0;i < toppingsCheckboxes.length;i++){
    if(toppingsCheckboxes[i].checked){
      order.toppings.push(toppingsCheckboxes[i].value);
    }
  }
  
  
  order.extraCheese = document.getElementById('extra-cheese-input').checked;
  order.extraSauce = document.getElementById('extra-sauce-input').checked;
  
  return order;
}

function makeInvoice(order){
  var price = order.size;
  price = price + (order.toppings.length * 1.5);
  if(order.extraCheese == true) {
    price = price + 1;
  }
  
  var toppingList = "";
  for(var i = 0; i < order.toppings.length;i++){
    toppingList = toppingList + order.topping[i] + ", ";
  }
  
  var extraCheese = "";
  if(order.extraCheese) {
    extraCheese = "extra cheese, "
  }
  
  var extraSauce = "";
  if(order.extraSauce) {
    extraSauce = "extra Sauce"
  }
  
  var invoice = "Your total is $" + price.toFixed(2) 
  + " for a " 
  + order.size 
  + "\" pizza with " 
  + order.crust
  + " crust, "
  + order.sauce
  + " sauce, "
  + toppingList
  + extraCheese
  + extraSauce
  +". Thank you for ordering with us!";
  
  return invoice;
}


function handleOrderClick(){
  
  var order = buildOrder();
  
  //console.log(order);
  
  if(validate(order)){
    alert(makeInvoice(order));
  }
}